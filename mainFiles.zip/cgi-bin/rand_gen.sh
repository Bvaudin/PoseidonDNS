while :; do echo $((54 + RANDOM % 30)) > rand_ref; sleep 3600; done
